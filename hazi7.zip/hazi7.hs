module Hazisok where 

    doubleDivBy3 :: Int -> Int
    doubleDivBy3 a 
     | a `mod` 3==0 = a*2
     | otherwise =a


    doubleDivBy3Map :: [Int] -> [Int ]
    doubleDivBy3Map = map doubleDivBy3

    isOverheating :: Double -> Bool
    isOverheating a = celsius > 95
     where celsius = a -273.15

    isOverheatingList :: [Double] -> [Bool]
    isOverheatingList = map isOverheating