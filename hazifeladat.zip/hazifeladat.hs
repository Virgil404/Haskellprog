 module Hazi1 where 

    myname :: String
    myname = "Sanyi"
    
    average ::  Double-> Double -> Double -> Double
    average a b c = (a*b*c)/3

    tegla :: Double -> Double -> Double -> Double
    tegla a b c = a*b*c