module Utcsohazi where 
data Vehicle = Truck { manufacturer :: String,
                       weight :: Int,
                       maxLoad :: Int,
                       fuelConsumption :: Float,
                       mileage :: Int,
                       available :: Bool,
                       id :: Int
                     }
             | Van { manufacturer :: String,
                     maxLoad :: Int,
                     fuelConsumption :: Float,
                     available :: Bool,
                     id :: Int
                   }

tr1 :: Vehicle
tr1 = Truck "Iveco" 7900 15000 25.5 425315 True 87

tr2 :: Vehicle
tr2 = Truck "Mercedes" 12100 12000 38.5 243103 True 44

tr3 :: Vehicle
tr3 = Truck "Mercedes" 13600 8000 23.5 156078 False 63

vn1 :: Vehicle
vn1 = Van "Renault" 1500 10.9 True 31

vn2 :: Vehicle
vn2 = Van "Ford" 1600 11.7 False 98


efficientTruck :: Vehicle -> Bool
efficientTruck (Truck _ _ maxLoad fuelConsumption _ _ _) = fuelConsumption * fromIntegral maxLoad / 100 < 4000
efficientTruck _ = False


pickVehicle :: [Vehicle] -> Int -> Int
pickVehicle [] _ = error "No suitable vehicle found."
pickVehicle ((Truck _ _ maxLoad _ _ available id):vs) weight
    | weight <= maxLoad && available = id
    | otherwise = pickVehicle vs weight
pickVehicle ((Van _ maxLoad _ available id):vs) weight
    | weight <= maxLoad && available = id
    | otherwise = pickVehicle vs weight
